package com.example.plato;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.example.plato.FragmentsClasses.Chat.ChatFragment;
import com.example.plato.FragmentsClasses.people.PeopleFragment;
import com.example.plato.MainActivity;
import com.example.plato.R;
import com.example.plato.myThread;

public class AddActivity extends AppCompatActivity {
    String newFriend;
    private myThread mt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_add);
        Button button=findViewById(R.id.button3);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submiadd();
            }
        });

        mt=new myThread("6");
        mt.start();
    }

    public void submiadd() {
        final EditText editText=findViewById(R.id.editText);
        newFriend=editText.getText().toString();
        mt.sendMessage(newFriend);
        //ChatFragment.personList.add(new Person(newFriend));
    }
}
