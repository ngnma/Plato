package com.example.plato;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.plato.FragmentsClasses.Chat.ChatFragment;

import java.text.SimpleDateFormat;
import java.util.Locale;

public class ChatPageActivity extends AppCompatActivity {
    int size;
    private myThread mt,mt2;
    public RecyclerView chatPersonRecyclerView;
    public ChatPageAdapter chatAdapter;
    public static String chatPersonItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_chat_page);
        Button submit=findViewById(R.id.chatSendBtn);

        mt2=new myThread("2",ChatFragment.personList.get(size).getName());
        mt2.start();

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMessageToServer();
            }
        });

        updateList();

        size=getIntent().getIntExtra("data1",0);

        chatPersonRecyclerView=findViewById(R.id.message_list);
        chatPersonRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        chatAdapter=new ChatPageAdapter(size);
        chatPersonRecyclerView.setAdapter(chatAdapter);
        chatPersonRecyclerView.setItemAnimator(new DefaultItemAnimator());


        ChatFragment.adapter.notifyDataSetChanged();
        ChatFragment.chatRecyclerView.invalidate();
    }
    public void sendMessageToServer(){

        final EditText editText=findViewById(R.id.chatMessageBox);
        String newMessage=editText.getText().toString();
        String receiverMessage=ChatFragment.personList.get(size).getName();
        MessageChat message=ChatFragment.personList.get(size).setMessage(newMessage,true);
        SimpleDateFormat formatter = new SimpleDateFormat("HH:mm", Locale.US);
        String timeMessage = formatter.format(message.getSentDate());
        String finalMessage=MainActivity.mUserName.concat("&"+receiverMessage+"&"+timeMessage+"&"+newMessage);
        mt=new myThread("11",finalMessage);
        mt.start();
        chatAdapter.notifyDataSetChanged();
        chatPersonRecyclerView.invalidate();
    }

    private void updateList(){
        Thread listener = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String[] list = ChatPageActivity.chatPersonItems.split("#");
                    ChatFragment.personList.get(size).getChats().clear();
                    for (String val : list) {
                        String [] msg=val.split("&");
                        boolean fm;
                        if(msg[1].equals(MainActivity.mUserName)){fm=false;}
                        else {fm=true;}
                        ChatFragment.personList.get(size).setMessage(msg[3],fm,msg[2]);
                    }
                } catch (NullPointerException e) {updateList();}
            }
        });
        listener.start();
    }
}