package com.example.plato;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.plato.FragmentsClasses.Chat.ChatFragment;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ChatPageAdapter extends RecyclerView.Adapter {
    private List<MessageChat> list;
    int size;
    ChatPageAdapter(int size){
        this.size = size;
        list=new ArrayList<>();
        list=ChatFragment.personList.get(size).getChats();
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_message_chat, parent, false);
        return new ChatPageAdapter.MessageViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ChatPageAdapter.MessageViewHolder mvh = (ChatPageAdapter.MessageViewHolder)holder;
        mvh.bind(list.get(position));

        if(list.get(position).isSending()){
            //((MessageViewHolder) holder).messageText.setBackgroundColor(Color.parseColor("#CC3366"));
            //((MessageViewHolder) holder).messageText.setBackground(Drawable.createFromPath("@drawable/sending_message_rect"));
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class MessageViewHolder extends RecyclerView.ViewHolder{
        TextView messageText, timeText, nameText;

        public MessageViewHolder(View itemView){
            super(itemView);
            messageText = itemView.findViewById(R.id.messageBodyChat);
            timeText= itemView.findViewById(R.id.messageTimeChat);
            nameText = itemView.findViewById(R.id.messagePersonNameChat);
        }

        void bind(MessageChat message) {
            messageText.setText(message.getBody());
            timeText.setText(message.getTime());
            nameText.setText(message.getSender());

        }

    }
}
