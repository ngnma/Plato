package com.example.plato.FragmentsClasses.Chat;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.plato.MainActivity;
import com.example.plato.MessageChat;
import com.example.plato.Person;
import com.example.plato.R;
import com.example.plato.myThread;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChatFragment extends Fragment {
public static List<Person> personList=new ArrayList<>();
public static ChatFragmentAdapter adapter;
private myThread mt;
public static RecyclerView chatRecyclerView;
public static String chatItems;




    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mt=new myThread("3");mt.start();
    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root=inflater.inflate(R.layout.fragment_chat,container,false);

        updateList();

        chatRecyclerView = root.findViewById(R.id.message_list);
        chatRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        adapter = new ChatFragmentAdapter();
        chatRecyclerView.setAdapter(adapter);
        chatRecyclerView.setItemAnimator(new DefaultItemAnimator());

        ChatFragment.adapter.notifyDataSetChanged();
        ChatFragment.chatRecyclerView.invalidate();
        return root;
    }
    public void updateList(){
        Thread rece = new Thread(new Runnable() {
            @Override
            public void run() {
                    try {
                        String[] list = ChatFragment.chatItems.split(",");
                        ChatFragment.personList.clear();
                        for (String val : list) {
                            ChatFragment.personList.add(new Person(val));
                        }
                    } catch (NullPointerException e) {updateList();}
            }
        });
        rece.start();
    }

}
