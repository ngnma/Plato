package com.example.plato.FragmentsClasses.Chat;

import android.content.Context;
import android.content.Intent;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.plato.ChatPageActivity;
import com.example.plato.Person;
import com.example.plato.R;


public class ChatFragmentAdapter extends RecyclerView.Adapter {
    Context context;

    public static class ChatFragmentViewHolder extends RecyclerView.ViewHolder{
        TextView nameText;
        ConstraintLayout mainLayout;

        public ChatFragmentViewHolder(View itemView){
            super(itemView);
            nameText = itemView.findViewById(R.id.person_name);
            mainLayout = itemView.findViewById(R.id.mainLayout);
        }


    }
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context=parent.getContext();
        View view = LayoutInflater.from(context).inflate(R.layout.item_person_name_chat, parent, false);
        return new ChatFragmentAdapter.ChatFragmentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        ((ChatFragmentViewHolder) holder).nameText.setText(ChatFragment.personList.get(position).getName());
        ((ChatFragmentViewHolder) holder).mainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(context, ChatPageActivity.class);
                intent.putExtra("data1",position);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        try {
            return ChatFragment.personList.size();
        }catch (NullPointerException e){return 0;}

    }
}
