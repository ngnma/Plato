package com.example.plato.FragmentsClasses.game;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.plato.HomePageActivity;
import com.example.plato.R;
import com.example.plato.RoomsXOActivity;
import com.example.plato.XoActivity;

public class GameFragment extends Fragment {
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root=inflater.inflate(R.layout.fragment_game,container,false);

        ImageView gameXO=root.findViewById(R.id.gameXO);
        gameXO.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(), "go to rooms page of xo", Toast.LENGTH_SHORT).show();
                final Intent intent=new Intent(getContext(), RoomsXOActivity.class);
                startActivity(intent);
            }
        });
        return root;
    }
}
