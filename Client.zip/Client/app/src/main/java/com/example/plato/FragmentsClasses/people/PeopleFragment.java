package com.example.plato.FragmentsClasses.people;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.plato.AddActivity;
import com.example.plato.FragmentsClasses.Chat.ChatFragment;
import com.example.plato.FragmentsClasses.Chat.ChatFragmentAdapter;
import com.example.plato.MainActivity;
import com.example.plato.Person;
import com.example.plato.R;
import com.example.plato.myThread;

import java.io.IOException;

public class PeopleFragment extends Fragment {
    private myThread mt;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mt=new myThread("3");
        mt.start();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root=inflater.inflate(R.layout.fragment_people,container,false);
        Button fab=root.findViewById(R.id.button4);

        final Intent intent=new Intent(getContext(), AddActivity.class);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(intent);
            }
        });



        updateList();

        ChatFragment.chatRecyclerView = root.findViewById(R.id.message_list2);
        ChatFragment.chatRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        ChatFragment.adapter = new ChatFragmentAdapter();
        ChatFragment.chatRecyclerView.setAdapter(ChatFragment.adapter);
        ChatFragment.chatRecyclerView.setItemAnimator(new DefaultItemAnimator());


        ChatFragment.adapter.notifyDataSetChanged();
        ChatFragment.chatRecyclerView.invalidate();

        return root;
    }
    public void updateList(){
        Thread rece = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String[] list = ChatFragment.chatItems.split(",");
                    ChatFragment.personList.clear();
                    for (String val : list) {
                        ChatFragment.personList.add(new Person(val));
                    }
                } catch (NullPointerException e) {updateList();}
            }
        });
        rece.start();
    }



}
