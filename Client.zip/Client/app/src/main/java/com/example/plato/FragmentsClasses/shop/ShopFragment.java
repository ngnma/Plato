package com.example.plato.FragmentsClasses.shop;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.plato.AboutUsActivity;
import com.example.plato.MainActivity;
import com.example.plato.R;
import com.example.plato.myThread;

public class ShopFragment extends Fragment {
private myThread mt;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root=inflater.inflate(R.layout.fragment_shop,container,false);

        Button logout=root.findViewById(R.id.logOut);
        Button aboutus=root.findViewById(R.id.aboutUs);
        final Intent intent=new Intent(getContext(),AboutUsActivity.class);


        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mt=new myThread("5");
                mt.start();
            }
        });


        aboutus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent);
            }
        });
        return root;
    }
}
