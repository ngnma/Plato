package com.example.plato;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.plato.FragmentsClasses.Chat.ChatFragment;
import com.example.plato.FragmentsClasses.game.GameFragment;
import com.example.plato.FragmentsClasses.home.HomeFragment;
import com.example.plato.FragmentsClasses.people.PeopleFragment;
import com.example.plato.FragmentsClasses.shop.ShopFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class HomePageActivity extends AppCompatActivity {
    private BottomNavigationView bottomNavigation;
    private myThread mt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        mt=new myThread("10");
        mt.start();
        bottomNavigation=this.findViewById(R.id.bottomNavigation);
        bottomNavigation.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.nav_home:
                        HomeFragment fragment=new HomeFragment();openFragment(fragment);break;
                    case R.id.nav_chat:
                        ChatFragment fragment2=new ChatFragment();openFragment(fragment2);break;
                    case R.id.nav_game:
                        GameFragment fragment3=new GameFragment();openFragment(fragment3);break;
                    case R.id.nav_shop:
                        ShopFragment fragment4 = new ShopFragment();openFragment(fragment4);break;
                    case R.id.nav_people:
                        PeopleFragment fragment5=new PeopleFragment();openFragment(fragment5);break;
                }
                return false;
            }
        });

        final Intent intent=new Intent(this,ProfileActivity.class);

        Button button2=this.findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent);
            }
        });
    }
    public void openFragment(Fragment fragment){
        FragmentTransaction transaction=getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container,fragment);
        transaction.commit();
    }
    }

