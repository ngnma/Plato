package com.example.plato;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;

public class MainActivity extends AppCompatActivity {
public static String mUserName,mPassword;
public static boolean firstTime;
String state="8";
private myThread mt;
public static Context context;

    boolean checkUser=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        firstTime=true;context=this;


        final Button button=this.findViewById(R.id.button);
        final Button login=this.findViewById(R.id.login);
        final Button create=this.findViewById(R.id.create);
        final TextView err=findViewById(R.id.err);


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               state="7";
                mt=new myThread(state);
                mt.start();

            }
        });

        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              state="8";
                mt=new myThread(state);
                mt.start();

            }
        });

        button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    submitUser(err);
                }
            });

    }

    public void submitUser(final TextView t) {
            mt.sendMessage(state);
        final EditText username = findViewById(R.id.username);
            mUserName = username.getText().toString();
            mt.sendMessage(mUserName);
        final EditText password = findViewById(R.id.password);
            mPassword = password.getText().toString();
            mt.sendMessage(mPassword);

        Thread listener = new Thread(new Runnable() {
            @Override
            public void run() {
                String a = null;
                try { a = mt.dis.readUTF(); } catch (IOException e) { e.printStackTrace(); }
                setText(t, a);
            }
        });
        listener.start();

    }

    private void setText(final TextView text,final String value){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                final Intent intent=new Intent(getApplicationContext(),HomePageActivity.class);
                text.setText(value);
                if(value.equals("okMessage")){startActivity(intent);}
            }
        });
    }

}