package com.example.plato;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MessageChat {
   private String sender,body;
   private Date sentDate;
   private boolean sending;
   private String timeHistory;
    boolean isHistory;
    public MessageChat(String sender, String body,boolean sending) {
        this.sender = sender;
        this.body = body;
        this.sending=sending;
        this.sentDate = new Date();
        isHistory=false;
    }
    public MessageChat(String sender, String body,boolean sending,String timeHistory) {
        this.sender = sender;
        this.body = body;
        this.sending=sending;
        this.timeHistory=timeHistory;
        isHistory=true;
    }

    public String getSender() {
        return sender;
    }

    public String getBody() { return body; }

    public Date getSentDate() {
        return sentDate;
    }

    public String getTime(){
        if(!isHistory){
            SimpleDateFormat formatter = new SimpleDateFormat("HH:mm", Locale.US);
            String time = formatter.format(getSentDate());
            return time;}
        else {
            return timeHistory;}
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public void setSentDate(Date sentDate) {
        this.sentDate = sentDate;
    }

    public void setSending(boolean sending) {
        this.sending = sending;
    }

    public boolean isSending() {
        return sending;
    }
}
