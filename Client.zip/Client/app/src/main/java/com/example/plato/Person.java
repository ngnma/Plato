package com.example.plato;

import java.util.ArrayList;
import java.util.List;

public class Person {
   String name;
   List<MessageChat> chats=new ArrayList<>();

    public Person(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public MessageChat setMessage(String text,boolean fromMe){
        String sender;
        if(fromMe) {sender=MainActivity.mUserName;}
        else {sender=getName();}
        MessageChat mc=new MessageChat(sender, text, fromMe);
        chats.add(mc);
        return mc;
    }

    public MessageChat setMessage(String text,boolean fromMe,String timeString){
        String sender;
        if(fromMe) {sender=MainActivity.mUserName;}
        else {sender=getName();}
        MessageChat mc=new MessageChat(sender, text, fromMe,timeString);
        chats.add(mc);
        return mc;
    }

    public List<MessageChat> getChats() {
        return chats;
    }
}
