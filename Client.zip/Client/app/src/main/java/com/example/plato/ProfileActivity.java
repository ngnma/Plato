package com.example.plato;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class ProfileActivity extends AppCompatActivity {
public static ImageView myProfile;
private myThread mt;
public static String mBio="Hey Im Using Plato!";

    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_profile);
        myProfile=findViewById(R.id.myProfile);
        FloatingActionButton fab = findViewById(R.id.fabProfile);
        TextView textViewUsername=findViewById(R.id.textViewUsername);
        TextView textViewBio=findViewById(R.id.textViewBio);
        Button setbtn=findViewById(R.id.ok);

        textViewUsername.setText(MainActivity.mUserName);
        textViewBio.setText(mBio);

        setbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submiBio();
            }
        });

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ProfileActivity.this, ProfilesShowActivity.class);
                startActivity(intent);
            }
        });
        mt=new myThread("1");
        mt.start();

    }
    public void submiBio(){
        final EditText editTextBio=findViewById(R.id.editTextBio);
        mBio=editTextBio.getText().toString();
        mt.sendMessage(mBio);
    }
}
