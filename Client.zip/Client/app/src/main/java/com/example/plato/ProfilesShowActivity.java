package com.example.plato;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class ProfilesShowActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profiles_show);
        ImageView i1=findViewById(R.id.prof11);
        i1.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceType")
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "clicked on p1", Toast.LENGTH_SHORT).show();
                ProfileActivity.myProfile.setImageDrawable(getResources().getDrawable(R.drawable.profile11));
//                Thread t=new Thread(new Runnable() {
//                    @Override
//                    public void run() {
//                        ProfileActivity.myProfile.setImageResource(R.drawable.profile11);
//                    }
//                });t.start();
            }
        });
    }
}
