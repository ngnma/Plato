package com.example.plato;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class RoomsXOActivity extends AppCompatActivity {
private myThread mt;
public static boolean acceptedRoom=false;
public static  String acceptingMessage;
public static boolean isCreater;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rooms_x_o);
        Button createRoom=findViewById(R.id.createRoom);
        Button joinRoom=findViewById(R.id.joinRoom);
        final Intent intent=new Intent(getApplicationContext(),XoActivity.class);

        createRoom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mt=new myThread("14");
                mt.start();
                isCreater=true;
                startActivity(intent);
            }
        });

        joinRoom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isCreater=false;
                joiningAcception();
            }
        });

    }
    public void joiningAcception() {
        mt=new myThread("15");
        mt.start();
        while (true) {
            try {
                acceptingMessage = mt.dis.readUTF();
                if (!acceptingMessage.equals("wait")) {
                    final Intent intent = new Intent(getApplicationContext(), XoActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(getApplicationContext(), "waiting list is empty", Toast.LENGTH_SHORT).show();
                }
                break;
            } catch (Exception e) {
            }
        }
    }
}
