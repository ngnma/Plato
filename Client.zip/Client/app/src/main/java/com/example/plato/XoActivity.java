package com.example.plato;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class XoActivity extends AppCompatActivity {
private myThread mt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_xo);

        if (RoomsXOActivity.isCreater) {
            final ImageView xo1 = findViewById(R.id.xo1);
            xo1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    xo1.setImageDrawable(getResources().getDrawable(R.drawable.ic_close_black_24dp));
                }
            });
            Thread listeningToServer = new Thread(new Runnable() {
                @Override
                public void run() {
                    while (true) {
                        try {
                            if(mt.dis.available()>0){
                            RoomsXOActivity.acceptingMessage = mt.dis.readUTF();}
                            Toast.makeText(getApplicationContext(), RoomsXOActivity.acceptingMessage + " is connected!game started!", Toast.LENGTH_SHORT).show();
                            mt.dos.writeUTF(RoomsXOActivity.acceptingMessage);mt.dos.flush();
                            startGame();
                            break;
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            });
            listeningToServer.start();
        }
        else{
            Toast.makeText(getApplicationContext(), RoomsXOActivity.acceptingMessage + " was waiting for you!game started!", Toast.LENGTH_SHORT).show();
            startGame();}



    }
    public void startGame(){
        final ImageView xo1 = findViewById(R.id.xo1);
        final ImageView xo2 = findViewById(R.id.xo2);
        final ImageView xo3 = findViewById(R.id.xo3);
        final ImageView xo4 = findViewById(R.id.xo4);
        final ImageView xo5 = findViewById(R.id.xo5);
        final ImageView xo6 = findViewById(R.id.xo6);
        final ImageView xo7 = findViewById(R.id.xo7);
        final ImageView xo8 = findViewById(R.id.xo8);
        final ImageView xo9 = findViewById(R.id.xo9);
        TextView frontClient=findViewById(R.id.frontClient);
        frontClient.setText(RoomsXOActivity.acceptingMessage);

        final String[] serverMessage = { null };

        Thread converstationWithServer=new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    if(RoomsXOActivity.isCreater){yourTurn();}
                    while (true) {
                        try {
                            serverMessage[0] = mt.dis.readUTF();
                            break;
                        } catch (Exception e) {}
                    }
                    Toast.makeText(getApplicationContext(), serverMessage[0], Toast.LENGTH_SHORT).show();
                    switch (serverMessage[0]){
                        case "win":break;
                        case "lose":break;
                        case "equal":break;
                        case "0":xo1.setImageDrawable(getResources().getDrawable(R.drawable.ic_panorama_fish_eye_black_24dp));
                        case "1":xo2.setImageDrawable(getResources().getDrawable(R.drawable.ic_panorama_fish_eye_black_24dp));
                        case "2":xo3.setImageDrawable(getResources().getDrawable(R.drawable.ic_panorama_fish_eye_black_24dp));
                        case "3":xo4.setImageDrawable(getResources().getDrawable(R.drawable.ic_panorama_fish_eye_black_24dp));
                        case "4":xo5.setImageDrawable(getResources().getDrawable(R.drawable.ic_panorama_fish_eye_black_24dp));
                        case "5":xo6.setImageDrawable(getResources().getDrawable(R.drawable.ic_panorama_fish_eye_black_24dp));
                        case "6":xo7.setImageDrawable(getResources().getDrawable(R.drawable.ic_panorama_fish_eye_black_24dp));
                        case "7":xo8.setImageDrawable(getResources().getDrawable(R.drawable.ic_panorama_fish_eye_black_24dp));
                        case "8":xo9.setImageDrawable(getResources().getDrawable(R.drawable.ic_panorama_fish_eye_black_24dp));
                    }
                    if(!RoomsXOActivity.isCreater){yourTurn();}
                }
            }
        });converstationWithServer.start();
    }

    private boolean yourTurn(){
        final boolean[] waitingForChoice = {true};
        Toast.makeText(getApplicationContext(), "your turn", Toast.LENGTH_SHORT).show();
        final ImageView xo1 = findViewById(R.id.xo1);
        final ImageView xo2 = findViewById(R.id.xo2);
        final ImageView xo3 = findViewById(R.id.xo3);
        final ImageView xo4 = findViewById(R.id.xo4);
        final ImageView xo5 = findViewById(R.id.xo5);
        final ImageView xo6 = findViewById(R.id.xo6);
        final ImageView xo7 = findViewById(R.id.xo7);
        final ImageView xo8 = findViewById(R.id.xo8);
        final ImageView xo9 = findViewById(R.id.xo9);
        while (waitingForChoice[0]) {
            xo1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(), "0", Toast.LENGTH_SHORT).show();
                    try {
                        mt.dos.writeUTF("0");
                        mt.dos.flush();
                        xo1.setImageDrawable(getResources().getDrawable(R.drawable.ic_close_black_24dp));
                        waitingForChoice[0] = false;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });
            xo2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(), "1", Toast.LENGTH_SHORT).show();
                    try {
                        mt.dos.writeUTF("1");
                        mt.dos.flush();
                        xo2.setImageDrawable(getResources().getDrawable(R.drawable.ic_close_black_24dp));
                        waitingForChoice[0] = false;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });
            xo3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(), "2", Toast.LENGTH_SHORT).show();
                    try {
                        mt.dos.writeUTF("2");
                        mt.dos.flush();
                        xo3.setImageDrawable(getResources().getDrawable(R.drawable.ic_close_black_24dp));
                        waitingForChoice[0] = false;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });
            xo4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(), "3", Toast.LENGTH_SHORT).show();
                    try {
                        mt.dos.writeUTF("3");
                        mt.dos.flush();
                        xo4.setImageDrawable(getResources().getDrawable(R.drawable.ic_close_black_24dp));
                        waitingForChoice[0] = false;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });
            xo5.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(), "4", Toast.LENGTH_SHORT).show();
                    try {
                        mt.dos.writeUTF("4");
                        mt.dos.flush();
                        xo5.setImageDrawable(getResources().getDrawable(R.drawable.ic_close_black_24dp));
                        waitingForChoice[0] = false;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });
            xo6.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(), "5", Toast.LENGTH_SHORT).show();
                    try {
                        mt.dos.writeUTF("5");
                        mt.dos.flush();
                        xo6.setImageDrawable(getResources().getDrawable(R.drawable.ic_close_black_24dp));
                        waitingForChoice[0] = false;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });
            xo7.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(), "6", Toast.LENGTH_SHORT).show();
                    try {
                        mt.dos.writeUTF("6");
                        mt.dos.flush();
                        xo7.setImageDrawable(getResources().getDrawable(R.drawable.ic_close_black_24dp));
                        waitingForChoice[0] = false;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });
            xo8.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(), "7", Toast.LENGTH_SHORT).show();
                    try {
                        mt.dos.writeUTF("7");
                        mt.dos.flush();
                        xo8.setImageDrawable(getResources().getDrawable(R.drawable.ic_close_black_24dp));
                        waitingForChoice[0] = false;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });
            xo9.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(), "8", Toast.LENGTH_SHORT).show();
                    try {
                        mt.dos.writeUTF("8");
                        mt.dos.flush();
                        xo9.setImageDrawable(getResources().getDrawable(R.drawable.ic_close_black_24dp));
                        waitingForChoice[0] = false;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });
        }
        return true;
    }
}
