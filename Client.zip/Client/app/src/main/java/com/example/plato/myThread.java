package com.example.plato;

import com.example.plato.FragmentsClasses.Chat.ChatFragment;

import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;

public class myThread extends Thread {
    Socket socket ;
    DataOutputStream dos ;
    public DataInputStream dis ;
    String status,messageShouldBeSend;
    myThread(){}
    public myThread(String status){ this.status=status; }
    public myThread(String status,String messageShouldBeSend){
        this.status=status;
        this.messageShouldBeSend=messageShouldBeSend;
    }
    @Override
    public void run() {
        super.run();
        try {
            socket = new Socket("192.168.1.4", 4000);//1.4
            dos = new DataOutputStream(socket.getOutputStream());
            dis=new DataInputStream(socket.getInputStream());
            switch (status){
                case "1":connectToServer();break;//change bio
                case "2":connectToServer();sendMessage(messageShouldBeSend);ChatPageActivity.chatPersonItems=dis.readUTF();break;//load chatPage with sb
                case "3":connectToServer();ChatFragment.chatItems=dis.readUTF();break;//load list friend
                case "4":connectToServer();break;//game xo
                case "5":sendMessage(status);break;//log out
                case "6":connectToServer();break;//add friend
                case "7":break;//login
                case "8":break;//create new account
                case "10":connectToServer();ProfileActivity.mBio=dis.readUTF();break;//load bio
                case "11":connectToServer();sendMessage(messageShouldBeSend);break;//send message to sb
                case "12":connectToServer();break;
                case "14":connectToServer();break;
                case "15":connectToServer();break;
            }
        } catch (Exception e) { e.printStackTrace(); }
    }
    public void connectToServer() {
        try {
            sendMessage(status);
            sendMessage(MainActivity.mUserName);
        }catch (Exception e){}
    }

    public void sendMessage(String message){
        final String finalMessage=message;
        Thread sender=new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    dos.writeUTF(finalMessage);
                    dos.flush();
                } catch (IOException e) {e.printStackTrace(); }
            }
        });sender.start();
    }


    public String receiveMessage() {
        final String[] message = new String[1];
        Thread receiver=new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    while (dis.available()>0){
                    message[0] =dis.readUTF();break;}
                }catch (Exception e){}
            }
        });receiver.start();


        return message[0];
    }



}
