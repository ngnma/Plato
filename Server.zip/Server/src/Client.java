

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.net.Socket;
import java.util.HashMap;
import java.util.Scanner;

public class Client {


    public static void main(String[] args) throws Exception {

        Socket socket = new Socket("localhost", 4000);
        DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
        DataInputStream dis = new DataInputStream(socket.getInputStream());

        Scanner in = new Scanner(System.in);


        while (true) {

            try {
                System.out.println("Enter message ");
                dos.writeUTF(in.nextLine());

            } catch (IOException e) {
                e.printStackTrace();
            }


//        Thread messageListener = new Thread(new Runnable() {
//            @Override
//            public void run() {
//                while (true) {
//                    try {
//                        String message = dis.readUTF();
//                        System.out.println(message);
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    }
//                }
//            }
//        });
//        messageListener.start();
//
//        while (true) {
//
//            try {
//                System.out.println("Enter message ");
//                String s = in.nextLine();
//                dos.writeUTF(s);
//
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//
//
//        }


        }
    }}
