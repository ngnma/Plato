
import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ClientHandler implements Runnable {

    private Socket socket;
    private DataInputStream dis;
    private DataOutputStream dos;
    String username = "";

    ClientHandler(Socket socket) throws Exception {
        this.socket = socket;
        this.dis = new DataInputStream(socket.getInputStream());
        this.dos = new DataOutputStream(socket.getOutputStream());
    }

    @Override
    public void run() {
        String password = "";
        String newFriendUser = "";
        String targetname = "";
        List<String> waiting2;
        FileWriter fileWriter = null;
        FileWriter fileWriter2 = null;
        FileWriter fileWriter3 = null;
        FileWriter fileWriter4 = null;


        try {
            fileWriter = new FileWriter(Server.bioFile, true);
            fileWriter2 = new FileWriter(Server.passFile, true);
            fileWriter3 = new FileWriter(Server.friends, true);
            fileWriter4 = new FileWriter(Server.chatFile, true);
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            boolean isUsernameOk = false,isPasswordOk = false;

            System.out.println("someone connected!");
            Server.users.put(username, this);
            //System.out.println(Server.users.get(username));

                    String result = this.dis.readUTF();
                    System.out.println("User:" + username + ":"+result);

                    switch (result) {
                        case "1":/*changing bio from this client*/{
                            username=dis.readUTF();
                            System.out.println("User:" + username + " Connected!");
                            String newBio = dis.readUTF();
                            Server.bios.replace(username, newBio);
                            fileWriter.write(username + "*" + Server.bios.get(username) + "\n");
                            fileWriter.flush();
                            System.out.println("User:" + username + " added new bio:"+newBio);
                            break;}

                        case "2":/*chatList with sb*/{
                            username=dis.readUTF();
                            System.out.println("User:" + username + " Connected!");
                            targetname = dis.readUTF();
                            System.out.println("User:" + username + ":"+targetname);
                            String chatmessages = "";
                            FileReader fr = new FileReader(Server.chatFile);
                            BufferedReader br = new BufferedReader(fr);
                            String i;
                            String[] arr = null;
                            while ((i = br.readLine()) != null) {
                                arr = i.split("[&]");
                                if (i.contains(username)) {
                                    if ((arr[0].equals(targetname)) || (arr[1].equals(targetname)))
                                        chatmessages = chatmessages.concat(i + "#");
                                }
                            }
                            dos.writeUTF(chatmessages);
                            break;}

                        case "3":/*this client is in the friend page or chatlist page*/{
                            try {
                                username=dis.readUTF();
                                System.out.println("User:" + username + " Connected!");
                                FileReader fr2 = new FileReader(Server.friends);
                                BufferedReader br2 = new BufferedReader(fr2);
                                String t,added = "";
                                String[] words3 = null;
                                while ((t = br2.readLine()) != null) {
                                    words3 = t.split("[*]");
                                    if (t.contains(username)) {
                                        added = added.concat( words3[1]+",");
                                    }
                                }
                                this.dos.writeUTF(added);
                                this.dos.flush();
                                System.out.println("list:" + added);
                            }catch (Exception e){System.out.println("exception handeled");}
                            break;}

                        case "5":/*logging out*/ break;

                        case "6":/*add new friend*/{
                            username=dis.readUTF();
                            System.out.println("User:" + username + " Connected!");
                            newFriendUser = dis.readUTF();
                            fileWriter3.write(username + "*" + newFriendUser + "\n");
                            fileWriter3.flush();
                            System.out.println("User:" + username + " added user:"+newFriendUser+" as new friend");
                            break;}

                        case "7":/*login*/{
                            while (!isUsernameOk && !isPasswordOk) {
                                username = this.dis.readUTF();
                                password = this.dis.readUTF();
                                if (Server.pass.containsKey(username)) {
                                    isUsernameOk = true;
                                    if (Server.pass.get(username).equals(password)) {
                                        String okMessage = "okMessage";
                                        this.dos.writeUTF(okMessage);
                                        isPasswordOk = true;
                                        System.out.println("User:" + username + " Connected!");
                                    } else {
                                        String errorMessage = "errorMessage";
                                        this.dos.writeUTF(errorMessage);
                                    }
                                } else {
                                    String errorMessage = "errorMessage";//this username doesnt exist
                                    this.dos.writeUTF(errorMessage);
                                }
                            }
                            break;}

                        case "8":/*create new account*/{
                            while (!isUsernameOk && !isPasswordOk) {
                                username = this.dis.readUTF();
                                password = this.dis.readUTF();
                                if (Server.pass.containsKey(username)||password.length() <= 5) {//check if that username exists or not
                                    String errorMessage = "errorMessage";
                                    this.dos.writeUTF(errorMessage);
                                }
                                else {
                                    String errorMessage = "okMessage";
                                    this.dos.writeUTF(errorMessage);
                                    isUsernameOk = true;
                                    isPasswordOk = true;
                                    System.out.println("User:" + username + " Connected!");
                                }
                            }
                            fileWriter2.write(username + "*" + password + "\n");
                            fileWriter2.flush();
                            fileWriter.write(username + "*Hey Im Using Plato!\n");
                            fileWriter.flush();
                            Server.bios.put(username,"Hey Im Using Plato!");
                            break;}

                        case "10":/*sending bio from client to server*/{
                            username=dis.readUTF();
                            System.out.println("User:" + username + " Connected!");
                            this.dos.writeUTF(Server.bios.get(username));
                            break;}

                        case "11":/*send message to another client(chat)*/{
                            username=dis.readUTF();
                            System.out.println("User:" + username + " Connected!");
                            String incomingMessage=dis.readUTF();
                            System.out.println("User:"+username+"send message:"+incomingMessage);
                            fileWriter4.write(incomingMessage+"\n");
                            fileWriter4.flush();
                            break;}

                        case "14":/*create new room in game:XO */{
                            username=dis.readUTF();
                            System.out.println("User:" + username + " Connected!");
                            Server.users.put(username,this);
                            Server.waitingList.add(username);
                            System.out.println("User:" + username + ":create a new room");
                            //waiting for connecting another client
                            String front=null;
                            while (true){
                                try { front=this.dis.readUTF();
                                    System.out.println(front);
                                    break;
                                }catch (Exception e){}
                            }startGame(true,front);


//                            while (true){//game loop
//                                String createrChoice;
//                                while (true){//creater turn
//                                    try { createrChoice=this.dis.readUTF();break; }catch (Exception e){}
//                                }
//                                //logic
//                                //second ones turn
//                                //logic
//                                break;
//
//                            }

                            break;}

                        case "15":/*join */{
                            username=dis.readUTF();
                            System.out.println("User:" + username + " Connected!");
                            String creater=null;
                            System.out.println(Server.users.get(Server.waitingList.get(0))  );
                            if(Server.waitingList.size()==0){
                                creater="wait";
                                System.out.println("1");
                            }
                            else {
                                creater=Server.waitingList.get(0);
                                ClientHandler createrHandler=Server.users.get(creater);
                                createrHandler.dos.writeUTF(username);
                                System.out.println(username);

                                createrHandler.dos.flush();
                                Server.waitingList.remove(0);

                            }
                            this.dos.writeUTF(creater);
                            this.dos.flush();
                            startGame(false,creater);
                            System.out.println("3");

                            break;}
                    }



                System.out.println("finish progress");
                dis.close();dos.close();socket.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void startGame(boolean firstPlayer,String front) {
        try {
            ClientHandler frontH = Server.users.get(front);
            boolean[] isfulled = new boolean[9];
            for (int j = 0; j < isfulled.length; j++) {
                isfulled[j] = false;
            }
            int counter = 0;
            String input = "";
            String[] matrix = new String[9];
            for (int j = 0; j < matrix.length; j++) {
                matrix[j] = "";
            }
            while (true) {
                if (firstPlayer) {
                    input = this.dis.readUTF();
                }

                if (!isfulled[Integer.parseInt(input) - 1]) {
                    matrix[Integer.parseInt(input) - 1] = username;
                    isfulled[Integer.parseInt(input) - 1] = true;
                    counter++;
                }
                if (isWinnner(matrix, username)) {
                    frontH.dos.writeUTF("game over");
                    break;
                }
                frontH.dos.writeUTF(input);
                if (counter >= 9) {
                    this.dos.writeUTF("equal");
                    break;
                }
                if (!firstPlayer) {
                    input = this.dis.readUTF();
                }
            }
        }catch (Exception e){}
    }

static boolean isWinnner(String[] matrix, String name) {//worked correctly
        ArrayList<Integer> arr = new ArrayList<>();
        for (int i = 0; i < matrix.length; i++) {
        if (matrix[i].equals(name))
        arr.add(i);
        }
        if (arr.contains(0) && arr.contains(8) && arr.contains(4))
        return true;
        else if (arr.contains(2) && arr.contains(4) && arr.contains(6))
        return true;
        else if (arr.contains(1) && arr.contains(4) && arr.contains(7))
        return true;
        else if (arr.contains(3) && arr.contains(4) && arr.contains(5))
        return true;
        else if (arr.contains(0) && arr.contains(1) && arr.contains(2))
        return true;
        else if (arr.contains(6) && arr.contains(7) && arr.contains(8))
        return true;
        else if (arr.contains(2) && arr.contains(8) && arr.contains(5))
        return true;
        else if (arr.contains(0) && arr.contains(3) && arr.contains(6))
        return true;
        else return false;

        }
}