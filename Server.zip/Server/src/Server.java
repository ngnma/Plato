
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class Server {

    static HashMap<String, ClientHandler> users;
    static HashMap<String, String> pass;/*user-pass*/
    static HashMap<String, String> bios;/*user-bios*/
    static HashMap<String, String> allbiolist;
    static ArrayList<String> waitingList;


//    static File friends = new File("C:\\Users\\mahsa\\Documents\\finalProject\\friends.txt");
//    static File bioFile = new File("C:\\Users\\mahsa\\Documents\\finalProject\\bios.txt");
//    static File passFile = new File("C:\\Users\\mahsa\\Documents\\finalProject\\pass.txt");
//    static File chatFile = new File("C:\\Users\\mahsa\\Documents\\finalProject\\chat.txt");
//    static File waitFile = new File("C:\\Users\\mahsa\\Documents\\finalProject\\wait.txt");

    static File friends = new File("/Users/baran/Desktop/friends.txt");
    static File bioFile = new File("/Users/baran/Desktop/bios.txt");
    static File passFile = new File("/Users/baran/Desktop/pass.txt");
    static File chatFile = new File("/Users/baran/Desktop/chat.txt");

    public static void main(String[] args) throws Exception {

        ServerSocket serverSocket = new ServerSocket(4000);
        pass = new HashMap<String, String>();/*user-pass*/
        bios = new HashMap<String, String>();/*user-bios*/
        users = new HashMap<String, ClientHandler>();
        waitingList = new ArrayList<>();


        //read 3 Map of top from file and new Hasgmap from each one
        if (!friends.exists())
            friends.createNewFile();
        if (!bioFile.exists())
            bioFile.createNewFile();
        if (!passFile.exists())
            passFile.createNewFile();
        if (!chatFile.exists())
            chatFile.createNewFile();



        FileReader r = new FileReader(bioFile);
        BufferedReader b = new BufferedReader(r);
        String t;
        String[] words3 = null;
        while ((t = b.readLine()) != null) {   //Reading Content from the file
            words3 = t.split("[*]");//Split the word using *
            for (int i = 1; i < words3.length; i++) {
                bios.put(words3[0], words3[1]);
            }
        }//putting in bios is done


        FileReader r2 = new FileReader(passFile);
        BufferedReader b2 = new BufferedReader(r2);
        String t2;
        String[] words4 = null;
        while ((t2 = b2.readLine()) != null) {   //Reading Content from the file
            words4 = t2.split("[*]");//Split the word using *
            for (int i = 1; i < words4.length; i++) {
                pass.put(words4[0], words4[1]);
            }
        }//putting in pass is done correctly



        while (true) {
            Socket socket = serverSocket.accept();
            ClientHandler temp = new ClientHandler(socket);
            (new Thread(temp)).start();

        }

    }
}
